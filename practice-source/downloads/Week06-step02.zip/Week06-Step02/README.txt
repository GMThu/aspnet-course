第六週第 02 步
修改：只改 Index.cshtml.cs：加入 DataAnnotations 規則；暫時沒有閘門。
預期：Build 成功，但 OnPost 仍直接設定成功旗標；即使後端已有驗證錯誤，也還可能顯示成功。這是刻意保留的中間步驟，不可當成完成版。
全部解壓縮到獨立資料夾，開啟 Week05Registration.csproj。
需要 .NET 10 SDK。先停止其他練習網站，再 Build、Ctrl+F5。
未使用資料庫。請勿合併不同步驟，備份放在專案外。
