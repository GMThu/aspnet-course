第六週第 03 步
修改：只改 Index.cshtml.cs：在 Submitted = true 之前加 ModelState 閘門。
預期：Build 成功。合法資料仍顯示第五週摘要；不合法資料不顯示摘要，但尚未加入欄位錯誤訊息。
全部解壓縮到獨立資料夾，開啟 Week06Validation.csproj。
需要 .NET 10 SDK。先停止其他練習網站，再 Build、Ctrl+F5。
未使用資料庫。請勿合併不同步驟，備份放在專案外。
