﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Week05Registration.Pages;

public class PrivacyModel : PageModel
{
    public void OnGet()
    {
    }
}

