第六週驗證專案。由第五週複製，保留 Week05Registration.csproj 與 namespace，以便學生接續操作。
Mac 使用上一層 Start-Week06.command；Windows 開啟 Week05Registration.csproj。
本機測試用 HTTP，沒有資料庫。本版使用 novalidate，且不引入 _ValidationScriptsPartial，讓錯誤由後端 ModelState 判定。
