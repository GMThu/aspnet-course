本包：Week05-01-starter.zip
下一步：第五週第 02 步：先啟動首頁，再到第 03、04 步。尚未加入表單與自訂 CSS。

1. ZIP 右鍵 → 全部解壓縮，到新的資料夾。不要在 ZIP 裡編輯。
2. 找到同時有 Pages、wwwroot 與 Week05Registration.csproj 的那層。
3. Visual Studio → 開啟專案或方案 → 選 Week05Registration.csproj。
4. 需要 .NET 10 SDK 與 ASP.NET 與網頁程式開發工作負載；Ctrl+F5 執行。

備份請放在專案資料夾外，避免備份 .cs 一起被編譯。
本練習沒有資料庫，只使用假資料。
第六週保留 Week05Registration 專案名稱，以延續第五週 namespace。
