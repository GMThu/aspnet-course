using Microsoft.AspNetCore.Mvc.RazorPages;
namespace Week05Registration.Pages;
public class IndexModel : PageModel { public void OnGet() {} }
