第六週第 04 步
修改：只改 Index.cshtml：加入錯誤位置與 novalidate。
預期：空白送出顯示三個必填錯誤；Email=abc 顯示格式錯誤；合法資料顯示「報名資料驗證通過」。
全部解壓縮到獨立資料夾，開啟 Week05Registration.csproj。
需要 .NET 10 SDK。先停止其他練習網站，再 Build、Ctrl+F5。
未使用資料庫。請勿合併不同步驟，備份放在專案外。
