﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Week06Validation.Pages;

public class PrivacyModel : PageModel
{
    public void OnGet()
    {
    }
}

