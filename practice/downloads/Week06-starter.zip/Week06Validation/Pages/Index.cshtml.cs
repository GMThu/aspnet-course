using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Week06Validation.Pages;

public class IndexModel : PageModel
{
    public void OnGet() {}

    [BindProperty]
    public RegistrationInput Input { get; set; } = new();

    public bool Submitted { get; set; }

    public void OnPost()
    {
        Submitted = true;
    }
}

// 表單資料型別：與 IndexModel 放在同一檔案，位於 IndexModel 類別外。
public class RegistrationInput
{
    public string DisplayName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Session { get; set; } = string.Empty;
    public string? Note { get; set; }
}
