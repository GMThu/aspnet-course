第九週起始專案，基於第六週四欄位表單。先 dotnet run --launch-profile http；本階段尚未保存資料。依 ../start-here.html 順序套用 Checkpoints/01-Database、02-Save、03-Query 的檔案，目錄結構保持相同。不要直接改第六週原專案或覆蓋其他 namespace。
