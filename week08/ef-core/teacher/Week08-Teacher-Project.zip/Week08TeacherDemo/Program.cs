using Microsoft.EntityFrameworkCore;
using Week08TeacherDemo.Data;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddDbContext<CampusActivityContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("CampusActivity")));

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();
app.MapRazorPages();
app.Run();
